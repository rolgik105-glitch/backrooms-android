extends CharacterBody3D

@export var speed := 2.15
var target: Node3D
var active := true
var body_mesh: MeshInstance3D

func _ready() -> void:
    var capsule := CapsuleShape3D.new()
    capsule.radius = 0.42
    capsule.height = 1.9
    var shape := CollisionShape3D.new()
    shape.shape = capsule
    shape.position.y = 0.95
    add_child(shape)
    body_mesh = MeshInstance3D.new()
    var mesh := CapsuleMesh.new()
    mesh.radius = 0.42
    mesh.height = 1.9
    body_mesh.mesh = mesh
    body_mesh.position.y = 0.95
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.018, 0.016, 0.012)
    mat.roughness = 1.0
    mat.emission_enabled = true
    mat.emission = Color(0.025, 0.018, 0.008)
    body_mesh.material_override = mat
    add_child(body_mesh)
    target = get_tree().get_first_node_in_group("player")
    # Main scene assigns target after spawning as a fallback.
    if target == null:
        target = get_parent().get_node_or_null("Player")

func _physics_process(delta: float) -> void:
    if not active:
        return
    if target == null or not is_instance_valid(target):
        target = get_parent().get_node_or_null("Player")
        return
    var to_player := target.global_position - global_position
    to_player.y = 0
    if to_player.length() > 0.8:
        var dir := to_player.normalized()
        velocity.x = dir.x * speed
        velocity.z = dir.z * speed
        look_at(global_position + dir, Vector3.UP)
    else:
        velocity.x = 0
        velocity.z = 0
    if not is_on_floor():
        velocity.y -= 18.0 * delta
    else:
        velocity.y = -0.1
    move_and_slide()
