extends Node3D

const PLAYER_SCENE := preload("res://scenes/player.tscn")
const MONSTER_SCENE := preload("res://scenes/monster.tscn")

@export var maze_width := 17
@export var maze_depth := 17
@export var cell_size := 5.0
@export var wall_height := 3.4

var rng := RandomNumberGenerator.new()
var floor_mat: StandardMaterial3D
var wall_mat: StandardMaterial3D
var ceiling_mat: StandardMaterial3D
var exit_door: Node3D
var notes_found := 0
var hud_label: Label
var objective_label: Label
var monster: CharacterBody3D
var player: CharacterBody3D

func _ready() -> void:
    rng.randomize()
    _setup_input()
    _make_materials()
    _build_world()
    _spawn_player()
    _spawn_collectibles()
    _spawn_monster()
    _make_hud()
    _make_lighting()

func _setup_input() -> void:
    _add_key("move_forward", KEY_W)
    _add_key("move_back", KEY_S)
    _add_key("move_left", KEY_A)
    _add_key("move_right", KEY_D)
    _add_key("sprint", KEY_SHIFT)
    _add_key("interact", KEY_E)
    _add_key("flashlight", KEY_F)
    _add_key("crouch", KEY_CTRL)

func _add_key(action: String, key: Key) -> void:
    if not InputMap.has_action(action):
        InputMap.add_action(action)
    var ev := InputEventKey.new()
    ev.physical_keycode = key
    InputMap.action_add_event(action, ev)

func _make_materials() -> void:
    wall_mat = StandardMaterial3D.new()
    wall_mat.albedo_color = Color(0.68, 0.61, 0.34)
    wall_mat.roughness = 0.94
    wall_mat.metallic = 0.0
    wall_mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR

    floor_mat = StandardMaterial3D.new()
    floor_mat.albedo_color = Color(0.37, 0.29, 0.17)
    floor_mat.roughness = 1.0

    ceiling_mat = StandardMaterial3D.new()
    ceiling_mat.albedo_color = Color(0.48, 0.45, 0.32)
    ceiling_mat.roughness = 0.95

func _build_world() -> void:
    # Layout is deliberately irregular: several open rooms linked by narrow passages.
    var w := maze_width
    var d := maze_depth
    var grid: Array = []
    for z in range(d):
        var row: Array = []
        for x in range(w):
            var border := x == 0 or z == 0 or x == w - 1 or z == d - 1
            var block := border or (rng.randf() < 0.20 and x > 2 and z > 2)
            row.append(1 if block else 0)
        grid.append(row)

    # Carve a guaranteed connected wandering route.
    var cx := 1
    var cz := 1
    grid[cz][cx] = 0
    for i in range(240):
        if rng.randf() < 0.5:
            cx = clampi(cx + (1 if rng.randf() < 0.5 else -1), 1, w - 2)
        else:
            cz = clampi(cz + (1 if rng.randf() < 0.5 else -1), 1, d - 2)
        grid[cz][cx] = 0
        if i % 12 == 0:
            for oz in range(-1, 2):
                for ox in range(-1, 2):
                    if rng.randf() < 0.55:
                        grid[clampi(cz + oz, 1, d - 2)][clampi(cx + ox, 1, w - 2)] = 0

    # Start and exit zones.
    for z in range(1, 4):
        for x in range(1, 4):
            grid[z][x] = 0
    for z in range(d - 4, d - 1):
        for x in range(w - 4, w - 1):
            grid[z][x] = 0
    # Keep collectible locations and the exit in walkable cells.
    for spot in [Vector2i(5, 3), Vector2i(11, 8), Vector2i(14, 13)]:
        for oz in range(-1, 2):
            for ox in range(-1, 2):
                grid[spot.y + oz][spot.x + ox] = 0

    var floor_body := StaticBody3D.new()
    floor_body.name = "CarpetFloor"
    add_child(floor_body)
    _add_box(floor_body, Vector3(w * cell_size, 0.25, d * cell_size),
        Vector3((w - 1) * cell_size * 0.5, -0.15, (d - 1) * cell_size * 0.5), floor_mat, true)

    var ceiling_body := Node3D.new()
    ceiling_body.name = "Ceiling"
    add_child(ceiling_body)
    _add_box(ceiling_body, Vector3(w * cell_size, 0.22, d * cell_size),
        Vector3((w - 1) * cell_size * 0.5, wall_height, (d - 1) * cell_size * 0.5), ceiling_mat, false)

    for z in range(d):
        for x in range(w):
            if grid[z][x] == 1:
                var body := StaticBody3D.new()
                body.name = "WallpaperWall"
                add_child(body)
                _add_box(body, Vector3(cell_size, wall_height, cell_size),
                    Vector3(x * cell_size, wall_height * 0.5, z * cell_size), wall_mat, true)
            else:
                if rng.randf() < 0.12:
                    _add_pillar(Vector3(x * cell_size, 0, z * cell_size))
                if rng.randf() < 0.20:
                    _add_fluorescent(Vector3(x * cell_size, wall_height - 0.12, z * cell_size))

    # Exit marker at the far end.
    exit_door = Node3D.new()
    exit_door.name = "ExitDoor"
    exit_door.position = Vector3((w - 2) * cell_size, 0, (d - 2) * cell_size)
    add_child(exit_door)
    var door_mat := StandardMaterial3D.new()
    door_mat.albedo_color = Color(0.04, 0.32, 0.16)
    door_mat.emission_enabled = true
    door_mat.emission = Color(0.02, 0.16, 0.07)
    _add_box(exit_door, Vector3(1.5, 2.7, 0.18), Vector3(0, 1.35, 0), door_mat, false)

func _add_box(parent: Node, size: Vector3, pos: Vector3, mat: Material, collision: bool) -> void:
    var mesh_instance := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = size
    mesh_instance.mesh = mesh
    mesh_instance.position = pos
    mesh_instance.material_override = mat
    parent.add_child(mesh_instance)
    if collision:
        var shape := CollisionShape3D.new()
        var box := BoxShape3D.new()
        box.size = size
        shape.shape = box
        shape.position = pos
        parent.add_child(shape)

func _add_pillar(pos: Vector3) -> void:
    var body := StaticBody3D.new()
    add_child(body)
    var mat := wall_mat.duplicate()
    mat.albedo_color = Color(0.56, 0.51, 0.31)
    _add_box(body, Vector3(0.28, wall_height, 0.28), pos + Vector3(0, wall_height * 0.5, 0), mat, true)

func _add_fluorescent(pos: Vector3) -> void:
    var lamp := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = Vector3(1.45, 0.07, 0.42)
    lamp.mesh = mesh
    lamp.position = pos
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(1.0, 0.96, 0.72)
    mat.emission_enabled = true
    mat.emission = Color(0.9, 0.82, 0.52)
    mat.emission_energy_multiplier = 1.4
    lamp.material_override = mat
    add_child(lamp)
    var light := OmniLight3D.new()
    light.position = pos + Vector3(0, -0.18, 0)
    light.light_color = Color(1.0, 0.88, 0.57)
    light.light_energy = 0.55
    light.omni_range = 7.5
    light.shadow_enabled = false
    add_child(light)

func _make_lighting() -> void:
    var env := WorldEnvironment.new()
    var environment := Environment.new()
    environment.background_mode = Environment.BG_SKY
    environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    environment.ambient_light_color = Color(0.52, 0.48, 0.32)
    environment.ambient_light_energy = 0.7
    environment.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    environment.fog_enabled = true
    environment.fog_light_color = Color(0.55, 0.51, 0.34)
    environment.fog_density = 0.018
    env.environment = environment
    add_child(env)

func _spawn_player() -> void:
    player = PLAYER_SCENE.instantiate()
    add_child(player)
    player.position = Vector3(cell_size * 1.5, 1.0, cell_size * 1.5)
    player.set_meta("world", self)

func _spawn_collectibles() -> void:
    var spots := [
        Vector3(cell_size * 5.5, 0.9, cell_size * 3.5),
        Vector3(cell_size * 11.5, 0.9, cell_size * 8.5),
        Vector3(cell_size * 14.5, 0.9, cell_size * 13.5)
    ]
    for i in range(spots.size()):
        var note := MeshInstance3D.new()
        var mesh := BoxMesh.new()
        mesh.size = Vector3(0.35, 0.48, 0.025)
        note.mesh = mesh
        note.position = spots[i]
        note.name = "Note_%d" % i
        var mat := StandardMaterial3D.new()
        mat.albedo_color = Color(0.88, 0.83, 0.63)
        mat.roughness = 1.0
        note.material_override = mat
        note.set_meta("collectible", true)
        add_child(note)

func _spawn_monster() -> void:
    monster = MONSTER_SCENE.instantiate()
    add_child(monster)
    monster.position = Vector3(cell_size * 14.5, 0.9, cell_size * 2.5)
    monster.set_meta("world", self)
    monster.visible = false
    monster.set_physics_process(false)

func collect_note(note: Node3D) -> void:
    if not is_instance_valid(note):
        return
    note.queue_free()
    notes_found += 1
    hud_label.text = "ЗАПИСКИ: %d / 3" % notes_found
    objective_label.text = "Найди зелёную дверь" if notes_found >= 3 else "Найди записки: %d / 3" % (3 - notes_found)
    if notes_found == 1:
        monster.visible = true
        monster.set_physics_process(true)

func try_exit() -> void:
    if notes_found >= 3:
        objective_label.text = "ВЫХОД НАЙДЕН — ТЫ ВЫБРАЛСЯ!"
        hud_label.text = "УРОВЕНЬ 0 ПРОЙДЕН"
        get_tree().paused = true

func _make_hud() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    hud_label = Label.new()
    hud_label.position = Vector2(22, 18)
    hud_label.add_theme_font_size_override("font_size", 22)
    hud_label.add_theme_color_override("font_color", Color(1, 0.91, 0.64))
    hud_label.text = "ЗАПИСКИ: 0 / 3"
    layer.add_child(hud_label)
    objective_label = Label.new()
    objective_label.position = Vector2(22, 48)
    objective_label.add_theme_font_size_override("font_size", 16)
    objective_label.text = "Найди 3 записки"
    layer.add_child(objective_label)
    var controls := Label.new()
    controls.anchor_left = 0.0
    controls.anchor_top = 1.0
    controls.position = Vector2(20, -38)
    controls.text = "WASD — движение   Shift — бег   E — действие   F — фонарик"
    controls.add_theme_font_size_override("font_size", 13)
    controls.add_theme_color_override("font_color", Color(1, 1, 1, 0.72))
    layer.add_child(controls)
