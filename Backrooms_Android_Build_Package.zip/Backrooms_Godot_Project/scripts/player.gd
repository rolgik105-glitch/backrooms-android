extends CharacterBody3D

@export var walk_speed := 3.0
@export var sprint_speed := 5.2
@export var crouch_speed := 1.5
@export var mouse_sensitivity := 0.0022
@export var touch_sensitivity := 0.004
@export var gravity := 18.0

var camera: Camera3D
var flashlight: SpotLight3D
var pitch := 0.0
var touch_move := Vector2.ZERO
var active_touches := {}
var is_sprinting := false
var is_crouching := false
var flashlight_on := true

func _ready() -> void:
    name = "Player"
    add_to_group("player")
    Input.mouse_mode = Input.MOUSE_MODE_CAPTURED if not OS.has_feature("mobile") else Input.MOUSE_MODE_VISIBLE
    var collision := CollisionShape3D.new()
    var capsule := CapsuleShape3D.new()
    capsule.radius = 0.34
    capsule.height = 1.75
    collision.shape = capsule
    collision.position.y = 0.88
    add_child(collision)

    camera = Camera3D.new()
    camera.position = Vector3(0, 1.55, 0)
    camera.fov = 82.0
    camera.near = 0.05
    add_child(camera)
    flashlight = SpotLight3D.new()
    flashlight.position = Vector3(0.18, -0.12, -0.1)
    flashlight.rotation_degrees.x = -3
    flashlight.light_energy = 2.2
    flashlight.spot_range = 22
    flashlight.spot_angle = 34
    flashlight.shadow_enabled = true
    camera.add_child(flashlight)

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
        rotate_y(-event.relative.x * mouse_sensitivity)
        pitch = clampf(pitch - event.relative.y * mouse_sensitivity, -1.45, 1.45)
        camera.rotation.x = pitch
    elif event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
        Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
    elif event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
        if not OS.has_feature("mobile"):
            Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
    elif event is InputEventScreenTouch:
        var screen_size := get_viewport().get_visible_rect().size
        if event.pressed:
            # Large touch targets in the lower-right corner.
            if event.position.y > screen_size.y * 0.82 and event.position.x > screen_size.x * 0.82:
                flashlight_on = not flashlight_on
                flashlight.visible = flashlight_on
            elif event.position.y > screen_size.y * 0.82 and event.position.x > screen_size.x * 0.65:
                _interact()
            else:
                active_touches[event.index] = event.position
        else:
            active_touches.erase(event.index)
            _recalculate_touch_move()
    elif event is InputEventScreenDrag:
        if active_touches.has(event.index):
            var start: Vector2 = active_touches[event.index]
            if start.x > get_viewport().get_visible_rect().size.x * 0.42 and start.y < get_viewport().get_visible_rect().size.y - 130:
                rotate_y(-event.relative.x * touch_sensitivity)
                pitch = clampf(pitch - event.relative.y * touch_sensitivity, -1.45, 1.45)
                camera.rotation.x = pitch
            else:
                active_touches[event.index] = event.position
                _recalculate_touch_move()

func _recalculate_touch_move() -> void:
    touch_move = Vector2.ZERO
    var size := get_viewport().get_visible_rect().size
    for point in active_touches.values():
        if point.x < size.x * 0.48 and point.y > size.y * 0.38:
            var center := Vector2(size.x * 0.19, size.y * 0.77)
            touch_move = (Vector2(point) - center) / 70.0
            touch_move = touch_move.limit_length(1.0)

func _physics_process(delta: float) -> void:
    var input_dir := Vector2(
        Input.get_action_strength("move_right") - Input.get_action_strength("move_left"),
        Input.get_action_strength("move_back") - Input.get_action_strength("move_forward")
    )
    if touch_move.length() > 0.08:
        input_dir = Vector2(touch_move.x, touch_move.y)
    input_dir = input_dir.limit_length(1.0)
    is_sprinting = Input.is_action_pressed("sprint")
    is_crouching = Input.is_action_pressed("crouch")
    var speed := crouch_speed if is_crouching else (sprint_speed if is_sprinting else walk_speed)
    var direction := (transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()
    velocity.x = direction.x * speed
    velocity.z = direction.z * speed
    if not is_on_floor():
        velocity.y -= gravity * delta
    else:
        velocity.y = -0.1
    move_and_slide()

    if Input.is_action_just_pressed("flashlight"):
        flashlight_on = not flashlight_on
        flashlight.visible = flashlight_on
    if Input.is_action_just_pressed("interact"):
        _interact()

    # Touch screen lower-right action zones.
    for point in active_touches.values():
        var size := get_viewport().get_visible_rect().size
        if point.x > size.x * 0.82 and point.y > size.y * 0.78:
            if not flashlight_on:
                flashlight_on = true
                flashlight.visible = true

func _interact() -> void:
    var from := camera.global_position
    var to := from + -camera.global_transform.basis.z * 2.6
    var query := PhysicsRayQueryParameters3D.create(from, to)
    var hit := get_world_3d().direct_space_state.intersect_ray(query)
    if hit.is_empty():
        # Fallback proximity collection for paper notes and exit.
        var world := get_parent()
        for node in world.get_children():
            if node is Node3D and node.has_meta("collectible") and global_position.distance_to(node.global_position) < 2.0:
                world.collect_note(node)
                return
        if global_position.distance_to(Vector3(75, 0, 75)) < 3.0:
            world.try_exit()
        return
    var collider: Object = hit.get("collider")
    if collider is Node3D and collider.has_meta("collectible"):
        get_parent().collect_note(collider)
    elif collider is Node3D and collider.name == "ExitDoor":
        get_parent().try_exit()
